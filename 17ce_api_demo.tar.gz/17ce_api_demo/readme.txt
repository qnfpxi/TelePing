/*==============================================================================

			17ce websocket接口实例说明

==============================================================================*/

一. nodejs
	1.安装node环境

	2.打开node目录  安装ws模块
		sudo npm install ws

	3.修改程序ws_http.js 账号密码
		user  // 17ce邮箱账户
		api_pwd	 // 17ce后台APi Token

	4.执行程序
		node ws_http.js



二. html
	1.打开html目录

	3.修改静态页面index.html 账号密码
		user  // 17ce邮箱账户
		api_pwd	 // 17ce后台APi Token

	4.在浏览器打开静态页面 index.html